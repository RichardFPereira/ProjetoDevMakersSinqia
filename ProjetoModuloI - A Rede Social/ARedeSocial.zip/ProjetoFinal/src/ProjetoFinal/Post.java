package ProjetoFinal;

public class Post {
	String dataPost;
	String horaPost;
	String mensagemPost;
	
	public void criarPost(String data, String hora, String mensagem){
		dataPost = data;
	    horaPost = hora;
	    mensagemPost = mensagem;
	  }
}
